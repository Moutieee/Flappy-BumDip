FLAPPY BUMDIP — DOWNLOAD & SHARE EDITION
Current game export, 15 November 2026

PLAY NOW WITH FRIENDS
https://flappy-bumdip-sky.gaminghdwill.chatgpt.site/
This is already public. Send that link to friends for the shared leaderboard.
Each player plays their own run; this is not simultaneous multiplayer.

PLAY THIS DOWNLOAD
1. Extract the whole ZIP first.
2. Open index.html in a modern browser.
3. Click LETS GO SMOKING, choose a nickname, and play.
Keep the audio folder and all other files beside index.html.
Sound starts after interaction. Fonts may use a fallback offline.

UPLOAD YOUR OWN COPY
Upload all extracted files and the audio folder to a static HTML website host.
index.html must be in the host's published root folder.
If your host accepts ZIP uploads, upload this ZIP; otherwise extract it first.
No installation or build step is required.

IMPORTANT: SAVES AND LEADERBOARD
This portable edition saves nickname, shop items, Grams, discoveries, best scores,
and unlocks in the browser/device where it is played. Local file storage depends
on browser settings. Saves do not move automatically between domains or devices.

The shared account leaderboard and ChatGPT sign-in require the live hosted game.
This ZIP does not include a standalone account/leaderboard backend. Its leaderboard
button links to the live game. Grams earned in this ZIP do not sync to that board.
For everyone to compete on the same leaderboard, share the live link above.

CONTROLS
Space / Up arrow / click / tap: jump. P / Escape: pause. MENU: shop and collection.
Original game assets and audio are included. Publicly rehosting audio or branding
requires any permissions applicable to those assets.
